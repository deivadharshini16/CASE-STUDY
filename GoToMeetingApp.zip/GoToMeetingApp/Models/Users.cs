﻿namespace GoToMeetingApp.Models
{
    public class Users
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
